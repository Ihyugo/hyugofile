Galleriffic - a jQuery photo gallery & slideshow plugin
=======================================================

This is a fork of Galleriffic by Trent Foley. The original project can by found at http://www.twospy.com/galleriffic.

There are some outstanding issues which haven't been resolved since 2008, so this is an attempt to resolve those issues as well as enhance the functionality of the plugin for personal use.

Project modification by Jay Hayes (http://iamvery.com)


Integration with Fancybox
-------------------------
Check out the Galleriffic integration with Fancybox (http://fancybox.net) at https://github.com/iamvery/galleriffic/tree/v2.1.0.rc2