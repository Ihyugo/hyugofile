$(document).ready(function() {
  $('.pikit-container').children().pikit({
    height: 200
  })
})